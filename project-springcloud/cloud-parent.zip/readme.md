
## 是项目的一个父类工程管理依赖的
- 添加项目的所有的依赖
   - springcloud   all
   - springboot    parent
   - mybatis
   - web
   - mysql
