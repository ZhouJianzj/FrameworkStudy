1、实现用户的登录，根据username和password查询，得到不是一个空的对象就表示登录成功
并且设置token为true
2、成功之后实现session共享，方便每一次操作的权限认证问题
